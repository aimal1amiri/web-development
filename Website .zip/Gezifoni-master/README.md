# Gezifoni
Örnek bir gezi rehberi asp.net mvc 5 uygulaması.

Şehirlere ait kısa kısa bilgileri ve mekan detalarını saklayabilen. Üyelerin kayıt olarak şehirleri favorilerine eklediği ve mekan detaylarını, yol tariflerini, resimlerini, nerede ne yenir gibi detayları araştırarak inceleyebileceği. Basit düşünülmüş bir proje örneğidir. EF CodeFirst kullanılmıştır.

Projenin çalışır halinin görsellerine [screencaptures](https://github.com/muratbaseren/Gezifoni/tree/master/screencaptures) isimli klasör'den erişebilirsiniz.

![Ana Sayfa Görseli](https://github.com/muratbaseren/Gezifoni/blob/master/screencaptures/screencapture-01-homepage.png?raw=true)
