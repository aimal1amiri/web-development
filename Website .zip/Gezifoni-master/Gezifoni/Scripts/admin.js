﻿$(function () {
    $("#search_text").parent().remove();
})