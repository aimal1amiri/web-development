using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gezifoni.Infrastructure.Abstract;

namespace Gezifoni.ModalLogin
{
    internal partial class ModalLoginJsonResult : MyJsonResult<string>
    {

    }
}
